local ADDON, ns = ...
ns.Data = ns.Data or {}
ns.Data.POTIONS_SEED_VERSION = 10

-- Catégories explicites : "heal" (potion de soins), "util" (autres potions), "stone" (pierre de soins)
-- Renseigne ici ce que tu veux suivre exactement (si vide, heuristique nom/icône).
ns.Data.CONSUMABLES_TYPED = ns.Data.CONSUMABLES_TYPED or {
    util  = { 
        items = {
            212242, -- Délice cavernicole
            212243, -- Délice cavernicole
            212244, -- Délice cavernicole
            212948, -- Délice cavernicole fugace
            212949, -- Délice cavernicole fugace
            212950, -- Délice cavernicole fugace
            212263, -- Potion tempérée
            212264, -- Potion tempérée
            212265, -- Potion tempérée
            212969, -- Potion tempérée fugace
            212970, -- Potion tempérée fugace
            212971, -- Potion tempérée fugace
            212239, -- Potion de mana algarie
            212240, -- Potion de mana algarie
            212241, -- Potion de mana algarie
            248585, -- Essence ombrale
            248586, -- Essence ombrale
            248587, -- Essence ombrale
            212254, -- Flacon grotesque
            212255, -- Flacon grotesque
            212256, -- Flacon grotesque
            212257, -- Flacon de concentration inébranlable
            212258, -- Flacon de concentration inébranlable
            212259, -- Flacon de concentration inébranlable
            212260, -- Potion de ligne de front
            212261, -- Potion de ligne de front
            212262, -- Potion de ligne de front
            212266, -- Potion du guépard relevé
            212267, -- Potion du guépard relevé
            212268, -- Potion du guépard relevé
            212263, -- Potion tempérée
            212264, -- Potion tempérée
            212265, -- Potion tempérée
            212248, -- Breuvage de pas silencieux
            212249, -- Breuvage de pas silencieux
            212250, -- Breuvage de pas silencieux
            212251, -- Breuvage de révélation choquantes
            212252, -- Breuvage de révélation choquantes
            212253, -- Breuvage de révélation choquantes
        }, 
        spells = {
        }
    },
    heal  = { 
        items = {
            211878, -- Potion de soins algarie
            211879, -- Potion de soins algarie
            211880, -- Potion de soins algarie
            244837, -- Potion de soins revigorante
            244838, -- Potion de soins revigorante
            244839, -- Potion de soins revigorante
        }, 
        spells = {
        }
    },
    stone = { 
        items = {
            5512, -- Pierre de soins
        }, 
        spells = {
        }
    },
}

ns.Data.CONSUMABLE_CATEGORY = ns.Data.CONSUMABLE_CATEGORY or {}

ns.Data.CONSUMABLE_EXCLUDE_SPELLS = ns.Data.CONSUMABLE_EXCLUDE_SPELLS or {
    [82326] = true, -- Holy Light (Paladin) : ne doit JAMAIS être compté comme potion/prépot
}

-- Healthstones explicites (si connus)
ns.Data.HEALTHSTONE_SPELLS = ns.Data.HEALTHSTONE_SPELLS or {}
