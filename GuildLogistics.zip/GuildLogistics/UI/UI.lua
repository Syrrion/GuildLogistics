local ADDON, ns = ...
local Tr = ns and ns.Tr
local GLOG = ns.GLOG

ns.UI = ns.UI or {}
local UI = ns.UI

UI.DEFAULT_W, UI.DEFAULT_H = 1160, 680
UI.OUTER_PAD, UI.SCROLLBAR_W, UI.GUTTER, UI.ROW_H = 16, 20, 8, 28
UI.FONT_YELLOW = {1, 0.82, 0}
UI.WHITE = {1,1,1}
UI.ACCENT = {0.22,0.55,0.95}
UI.FOOTER_RIGHT_PAD = UI.FOOTER_RIGHT_PAD or 8
UI.TITLE_SYNC_PAD_RIGHT = UI.TITLE_SYNC_PAD_RIGHT or 40

-- Style des footers (centralisé)
UI.FOOTER_H            = UI.FOOTER_H            or 36
UI.FOOTER_BG           = UI.FOOTER_BG           or {0, 0, 0, 0.22}
UI.FOOTER_GRAD_TOP     = UI.FOOTER_GRAD_TOP     or {1, 1, 1, 0.05}
UI.FOOTER_GRAD_BOTTOM  = UI.FOOTER_GRAD_BOTTOM  or {0, 0, 0, 0.15}
UI.FOOTER_BORDER       = UI.FOOTER_BORDER       or {1, 1, 1, 0.12}

UI.TAB_EXTRA_GAP       = UI.TAB_EXTRA_GAP       or 14
UI.CONTENT_SIDE_PAD    = UI.CONTENT_SIDE_PAD    or -23
UI.CONTENT_BOTTOM_LIFT = UI.CONTENT_BOTTOM_LIFT or -20
UI.TAB_LEFT_PAD        = UI.TAB_LEFT_PAD        or 18

-- Utilitaires : formatage avec séparateur de milliers
UI.NUM_THOUSANDS_SEP = UI.NUM_THOUSANDS_SEP or " "
function UI.FormatThousands(v, sep)
    local n  = math.floor(math.abs(tonumber(v) or 0))
    local s  = tostring(n)
    local sp = sep or UI.NUM_THOUSANDS_SEP or " "
    local out, k = s, 0
    repeat
        out, k = out:gsub("^(%d+)(%d%d%d)", function(a, b) return a .. sp .. b end)
    until k == 0
    return out
end

function UI.MoneyText(v)
    v = tonumber(v) or 0
    local n = math.floor(math.abs(v) + 0.5)
    local iconG = "|TInterface\\MoneyFrame\\UI-GoldIcon:12:12:2:0|t"
    local txt = UI.FormatThousands(n) .. " " .. iconG
    if v < 0 then return "|cffff4040-" .. txt .. "|r" else return txt end
end

function UI.MoneyFromCopper(copper)
    local n = tonumber(copper) or 0
    local abs = math.abs(n)
    local g = math.floor(abs / 10000); local rem = abs % 10000
    local s = math.floor(rem / 100);   local c   = rem % 100
    local iconG = "|TInterface\\MoneyFrame\\UI-GoldIcon:12:12:2:0|t"
    local iconS = "|TInterface\\MoneyFrame\\UI-SilverIcon:12:12:2:0|t"
    local iconC = "|TInterface\\MoneyFrame\\UI-CopperIcon:12:12:2:0|t"
    local parts = {}
    if g > 0 then table.insert(parts, UI.FormatThousands(g) .. " " .. iconG) end
    if s > 0 then table.insert(parts, s .. " " .. iconS) end
    if c > 0 or #parts == 0 then table.insert(parts, c .. " " .. iconC) end
    local txt = table.concat(parts, " ")
    if n < 0 then return "|cffff4040-" .. txt .. "|r" else return txt end
end

-- ========= Couleurs utilitaires =========
-- Convertit des RGB [0..1] en "rrggbb"
function UI.RGBHex(r, g, b)
    local function clamp(x) x = tonumber(x) or 0; if x < 0 then return 0 elseif x > 1 then return 1 else return x end end
    r, g, b = clamp(r), clamp(g), clamp(b)
    return string.format("%02x%02x%02x", math.floor(r*255+0.5), math.floor(g*255+0.5), math.floor(b*255+0.5))
end

-- Entoure un texte avec un code couleur WoW
function UI.Colorize(text, r, g, b)
    return "|cff" .. UI.RGBHex(r,g,b) .. tostring(text) .. "|r"
end

-- Couleur "difficulté de quête" pour un niveau donné (par rapport au joueur)
function UI.ColorizeLevel(level)
    local lvl = tonumber(level)
    if not lvl or lvl <= 0 then return "" end

    local c = GetQuestDifficultyColor and GetQuestDifficultyColor(lvl)
    if not c or not c.r then
        -- Fallback simple si l'API n'est pas dispo
        local pl   = (UnitLevel and UnitLevel("player")) or lvl
        local diff = (lvl - pl)
        local greenRange = (GetQuestGreenRange and GetQuestGreenRange()) or 5
        if diff >= 5 then
            c = { r=1,   g=0.1, b=0.1 }       -- rouge
        elseif diff >= 3 then
            c = { r=1,   g=0.5, b=0.25 }      -- orange
        elseif diff >= -2 then
            c = { r=1,   g=0.82, b=0 }        -- jaune
        elseif diff > -greenRange then
            c = { r=0.25,g=0.75, b=0.25 }     -- vert
        else
            c = { r=0.5, g=0.5,  b=0.5 }      -- gris
        end
    end
    return "|cff" .. UI.RGBHex(c.r,c.g,c.b) .. tostring(lvl) .. "|r"
end


function UI.GetPopupAmountFromSelf(popupSelf)
    if not popupSelf then return 0 end
    local eb = popupSelf.editBox or popupSelf.EditBox
    if not eb then
        local n = popupSelf.GetName and popupSelf:GetName()
        if n and _G[n.."EditBox"] then eb = _G[n.."EditBox"] end
    end
    if eb then
        if eb.GetNumber then return eb:GetNumber()
        elseif eb.GetText then return tonumber(eb:GetText()) or 0 end
    end
    return 0
end

function UI.Key(s)
    s = tostring(s or "")
    s = s:gsub("[^%w_]", "_")
    return s
end

-- ===================== Fenêtre principale =====================
local Main = CreateFrame("Frame", "GLOG_Main", UIParent, "BackdropTemplate")
UI.Main = Main
local saved = GLOG.GetSavedWindow and GLOG.GetSavedWindow() or {}
Main:SetSize(saved.width or UI.DEFAULT_W, saved.height or UI.DEFAULT_H)
Main:SetFrameStrata("HIGH")
Main:SetMovable(true)
Main:EnableMouse(true)
Main:RegisterForDrag("LeftButton")
Main:SetScript("OnDragStart", function(self) self:StartMoving() end)
Main:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, relTo, relPoint, x, y = self:GetPoint()
    if GLOG.SaveWindow then
        GLOG.SaveWindow(point, relTo and relTo:GetName() or nil, relPoint, x, y, self:GetWidth(), self:GetHeight())
    end
end)
Main:SetResizable(true)
if Main.SetResizeBounds then Main:SetResizeBounds(980, 600) end
Main:SetScript("OnSizeChanged", function(self, w, h)
    if UI._layout then UI._layout() end
    local point, relTo, relPoint, x, y = self:GetPoint()
    if GLOG.SaveWindow then
        GLOG.SaveWindow(point, relTo and relTo:GetName() or nil, relPoint, x, y, w, h)
    end
end)
Main:SetPoint(saved.point or "CENTER", UIParent, saved.relPoint or "CENTER", saved.x or 0, saved.y or 0)

-- Habillage atlas Neutral
local skin = UI.ApplyNeutralFrameSkin(Main, { showRibbon = false })

-- Conteneur borné pour le contenu des onglets
Main.Content = CreateFrame("Frame", nil, Main)
local L,R,T,B = UI.OUTER_PAD, UI.OUTER_PAD, UI.OUTER_PAD, UI.OUTER_PAD
if Main._cdzNeutral and Main._cdzNeutral.GetInsets then
    L,R,T,B = Main._cdzNeutral:GetInsets()
end
local TAB_Y, TAB_H = -40, 18
local GAP   = UI.TAB_EXTRA_GAP or 15
local SIDE  = UI.CONTENT_SIDE_PAD or 12
local BOT   = UI.CONTENT_BOTTOM_LIFT or 6
Main.Content:SetPoint("TOPLEFT",     Main, "TOPLEFT",     L + SIDE, (TAB_Y - TAB_H - GAP))
Main.Content:SetPoint("BOTTOMRIGHT", Main, "BOTTOMRIGHT", -(R + SIDE), B + BOT)
Main.Content:SetClipsChildren(true)

-- Titre centré sur la barre de titre
Main.title = Main:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
do
    Main.title:SetText(GLOG.BuildMainTitle and GLOG.BuildMainTitle() or (Tr and Tr("main_title_guild")))
end
Main.title:SetTextColor(0.98, 0.95, 0.80)
do
    local _, _, TOP = skin:GetInsets()
    Main.title:ClearAllPoints()
    Main.title:SetPoint("TOP", Main, "TOP", 0, -(TOP - 38)) -- visuellement centré sur la frise
end

-- Bouton fermer standard (possibilité d'utiliser l'atlas UI-Frame-Neutral-ExitButtonBorder plus tard)
local close = CreateFrame("Button", nil, Main, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", Main, "TOPRIGHT", 2, 2)

-- ➕ Bouton Reload au même niveau que la croix (dans la barre titre)
local reloadBtn = CreateFrame("Button", ADDON.."ReloadButton", Main, "UIPanelButtonTemplate")
reloadBtn:SetSize(60, 20)
reloadBtn:SetText(Tr("btn_reload"))
-- S'assure d'être au-dessus du contenu, comme le bouton X
reloadBtn:SetFrameStrata(close:GetFrameStrata())
reloadBtn:SetFrameLevel(close:GetFrameLevel())

-- Placé juste à gauche du X
reloadBtn:ClearAllPoints()
reloadBtn:SetPoint("TOPRIGHT", close, "TOPLEFT", -6, 0)
reloadBtn:SetScript("OnClick", function() ReloadUI() end)

-- ➕ Bouton Debug à droite (collé au bouton Reload)
local debugBtn = CreateFrame("Button", ADDON.."DebugButton", Main, "UIPanelButtonTemplate")
debugBtn:SetText(Tr("tab_debug"))
-- Même taille/strata/niveau que Reload
local rw, rh = reloadBtn:GetSize()
if rw and rh then debugBtn:SetSize(rw, rh) else debugBtn:SetSize(60, 20) end
debugBtn:SetFrameStrata(reloadBtn:GetFrameStrata())
debugBtn:SetFrameLevel(reloadBtn:GetFrameLevel())
-- Position : juste à gauche de Reload (même marge que Reload vs Close)
debugBtn:ClearAllPoints()
debugBtn:SetPoint("TOPRIGHT", reloadBtn, "TOPLEFT", -6, 0)
-- Action : ouvre directement l'onglet Debug
debugBtn:SetScript("OnClick", function()
    if UI.ShowTabByLabel then UI.ShowTabByLabel(Tr("tab_debug")) end
end)

-- ➕ Expose des références globales pour contrôle de visibilité
UI.ReloadButton = reloadBtn
UI.DebugButton  = debugBtn

-- ➕ Indicateur de synchronisation (barre de titre, aligné à droite)
local syncPanel = CreateFrame("Frame", nil, Main)
syncPanel:Hide()
-- Même strata/level que la croix : passe au-dessus de l'overlay du skin
syncPanel:SetFrameStrata(close:GetFrameStrata())
syncPanel:SetFrameLevel(close:GetFrameLevel())

-- Positionneur : ancre au bord droit du bandeau rouge (titleRight),
-- centré verticalement dans ce bandeau, avec un padding configurable.
local function PositionSyncIndicator()
    syncPanel:ClearAllPoints()
    local pad = tonumber(UI.TITLE_SYNC_PAD_RIGHT or 12)

    local s  = Main._cdzNeutral
    local tr = s and s.title and s.title.right or nil
    if tr then
        -- Centré verticalement dans le bandeau + collé au bord droit du "TitleRight"
        syncPanel:SetPoint("RIGHT", tr, "RIGHT", -pad, 0)
    elseif debugBtn and debugBtn.GetObjectType then
        -- Fallback si la skin n'est pas encore prête
        syncPanel:SetPoint("TOPRIGHT", debugBtn, "TOPLEFT", -12, 0)
    elseif reloadBtn and reloadBtn.GetObjectType then
        syncPanel:SetPoint("TOPRIGHT", reloadBtn, "TOPLEFT", -12, 0)
    else
        syncPanel:SetPoint("TOPRIGHT", Main, "TOPRIGHT", -64, -2)
    end
end
PositionSyncIndicator()
syncPanel:SetHeight(20)

local syncText = syncPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
syncText:SetDrawLayer("OVERLAY", 3)
syncText:SetPoint("RIGHT", syncPanel, "RIGHT", 0, 0)
syncText:SetJustifyH("RIGHT")
syncText:SetText("")

-- Animation par points « … »
local syncTicker
local function _startSyncAnim(base)
    -- si 'base' est une clé, on traduit ; si c'est l'ancien texte FR/EN, l'alias fera le relais
    local keyOrLegacy = base or "sync_data"
    base = (Tr and Tr(keyOrLegacy)) or tostring(keyOrLegacy)
    if syncTicker and syncTicker.Cancel then syncTicker:Cancel() end
    local dots = 0
    syncPanel:Show()
    syncText:SetText(base .. "…")
    syncPanel:SetWidth(syncText:GetStringWidth() + 4)
    syncTicker = C_Timer.NewTicker(0.4, function()
        dots = (dots % 3) + 1
        local suffix = string.rep(".", dots)
        syncText:SetText(string.format("%s%s", base, suffix))
        syncPanel:SetWidth(syncText:GetStringWidth() + 4)
    end)
end

local function _stopSyncAnim()
    if syncTicker and syncTicker.Cancel then syncTicker:Cancel() end
    syncTicker = nil
    syncPanel:Hide()
end

-- API publique
function UI.SyncIndicatorShow(msg) _startSyncAnim(msg) end
function UI.SyncIndicatorHide() _stopSyncAnim() end

-- Coupe l’animation si la fenêtre est masquée
Main:HookScript("OnHide", function()
    if UI.SyncIndicatorHide then UI.SyncIndicatorHide() end
end)

-- Branchements : affichage dès réception du 1er fragment, arrêt à la fin
if ns and ns.On then
    ns.On("sync:begin", function()
        if UI.SyncIndicatorShow then UI.SyncIndicatorShow("sync_data") end
    end)
    ns.On("sync:end", function()
        if UI.SyncIndicatorHide then UI.SyncIndicatorHide() end
    end)
end

-- ===================== Tabs =====================
local Registered, Panels, Tabs = {}, {}, {}
UI._tabIndexByLabel = {}

-- UI.RegisterTab(label, build, refresh, layout, opts?) ; opts.hidden pour masquer le bouton d’onglet
function UI.RegisterTab(label, buildFunc, refreshFunc, layoutFunc, opts)
    table.insert(Registered, {
        label  = label,
        build  = buildFunc,
        refresh= refreshFunc,
        layout = layoutFunc,
        hidden = opts and opts.hidden or false,
    })
    UI._tabIndexByLabel[label] = #Registered
end

local function ShowPanel(idx)
    for i,p in ipairs(Panels) do p:SetShown(i == idx) end
    UI._current = idx
    for i, def in ipairs(Registered) do
        local b = def._btn
        if b then
            if i == idx then
                b.sel:Show()
                b:SetNormalFontObject("GameFontHighlightLarge")
            else
                b.sel:Hide()
                b:SetNormalFontObject("GameFontHighlight")
            end
        end
    end
end
UI.ShowPanel = ShowPanel

-- Création d’un bouton d’onglet basé sur le précédent visible
local function CreateTabButton(prevBtn, text)
    local b = CreateFrame("Button", nil, Main, "UIPanelButtonTemplate")
    b:SetText(text)
    b:SetSize(150, 26)
    if not prevBtn then
        local L = UI.OUTER_PAD
        if Main._cdzNeutral and Main._cdzNeutral.GetInsets then
            L = (Main._cdzNeutral:GetInsets())  -- récupère L,R,T,B ; on ne garde que L
        end
        b:SetPoint("TOPLEFT", Main, "TOPLEFT", L + (UI.TAB_LEFT_PAD or 12), -52)
    else
        b:SetPoint("LEFT", prevBtn, "RIGHT", 8, 0)
    end

    local sel = b:CreateTexture(nil, "OVERLAY")
    sel:SetColorTexture(UI.ACCENT[1], UI.ACCENT[2], UI.ACCENT[3], 0.8)
    sel:SetPoint("BOTTOMLEFT", b, "BOTTOMLEFT", 6, -3)
    sel:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -6, -3)
    sel:SetHeight(3)
    sel:Hide()
    b.sel = sel
    return b
end

function UI.Finalize()
    local lastBtn
    for i, def in ipairs(Registered) do
        local panel = CreateFrame("Frame", nil, Main.Content, "BackdropTemplate")
        panel:SetAllPoints(Main.Content)
        Panels[i] = panel
        def.panel = panel

        local bg = panel:CreateTexture(nil, "BACKGROUND")
        bg:SetColorTexture(1,1,1,0.03)
        bg:SetAllPoints()

        if def.build then def.build(panel) end

        if not def.hidden then
            local btn = CreateTabButton(lastBtn, def.label)
            btn:SetScript("OnClick", function() ShowPanel(i); if def.refresh then def.refresh() end end)
            def._btn = btn
            lastBtn = btn
            table.insert(Tabs, btn)
        else
            def._btn = nil
        end
    end
    UI._layout = function()
        -- Repositionne l'indicateur après tout reskin/redimensionnement.
        if PositionSyncIndicator then PositionSyncIndicator() end
        for i, def in ipairs(Registered) do
            if Panels[i]:IsShown() and def.layout then def.layout() end
        end
    end
end

-- Navigation par label
function UI.ShowTabByLabel(label)
    local idx = UI._tabIndexByLabel and UI._tabIndexByLabel[label]
    if idx then
        ShowPanel(idx)
        local def = Registered[idx]
        if def and def.refresh then def.refresh() end
    end
end


function UI.RefreshAll()
    local i = UI._current
    if i and Registered[i] and Registered[i].refresh then Registered[i].refresh() end
end
ns.RefreshAll = UI.RefreshAll

-- ➕ Récupération du bouton d'un onglet par label
function UI.GetTabButton(label)
    local idx = UI._tabIndexByLabel and UI._tabIndexByLabel[label]
    local def = idx and Registered[idx] or nil
    return def and def._btn, idx
end

-- ➕ Reflow des onglets visibles (sans « trous »)
function UI.RelayoutTabs()
    local lastBtn
    for i, def in ipairs(Registered) do
        local b = def._btn
        if b then
            b:ClearAllPoints()
            if b:IsShown() then
                if not lastBtn then
                    local L = UI.OUTER_PAD
                    if Main._cdzNeutral and Main._cdzNeutral.GetInsets then
                        L = (Main._cdzNeutral:GetInsets())
                    end
                    b:SetPoint("TOPLEFT", Main, "TOPLEFT", L + (UI.TAB_LEFT_PAD or 12), -52)
                else
                    b:SetPoint("LEFT", lastBtn, "RIGHT", 8, 0)
                end
                lastBtn = b
            end
        end
    end
end

-- ➕ Masquer/afficher un onglet avec fallback si on masque l'onglet actif
function UI.SetTabVisible(label, shown)
    local b, idx = UI.GetTabButton(label)
    if not b then return end
    local wasShown = b:IsShown()
    b:SetShown(shown and true or false)
    if (wasShown and not b:IsShown()) and UI._current == idx then
        -- bascule vers le 1er onglet visible
        for i, def in ipairs(Registered) do
            if def._btn and def._btn:IsShown() then
                UI.ShowPanel(i)
                if def.refresh then def.refresh() end
                break
            end
        end
    end
    UI.RelayoutTabs()
end

-- ➕ Visibilité des onglets selon l'appartenance à une guilde
function UI.ApplyTabsForGuildMembership(inGuild)
    local keepInfo     = Tr("tab_roster")     -- renommé « Info » via locales
    local keepSettings = Tr("tab_settings")
    local keepDebug    = Tr("tab_debug")
    local reqLabel     = Tr("tab_requests")

    -- État GM + nombre de demandes en attente
    local isGM = (ns.GLOG and ns.GLOG.IsMaster and ns.GLOG.IsMaster()) or false
    local reqCount = 0
    if isGM and ns.GLOG and ns.GLOG.GetRequests then
        local t = ns.GLOG.GetRequests()
        reqCount = (type(t) == "table") and #t or 0
    end

    for _, def in ipairs(Registered) do
        local lab = def.label
        local shown

        if lab == keepDebug then
            -- Le débug reste contrôlé par l’option UI
            shown = (GuildLogisticsUI and GuildLogisticsUI.debugEnabled) and true or false

        elseif lab == reqLabel then
            -- ⚠️ Jamais visible pour un joueur ; visible pour le GM seulement s'il existe des demandes
            shown = isGM and (reqCount > 0)
            UI.SetTabBadge(reqLabel, reqCount)

        else
            -- Visibilité standard selon appartenance à une guilde
            if inGuild then
                shown = true
            else
                shown = (lab == keepInfo) or (lab == keepSettings)
            end
        end

        UI.SetTabVisible(lab, shown)
    end
end

-- ➕ Bascule « débug » centralisée (persistance + visibilité)
function UI.SetDebugEnabled(enabled)
    GuildLogisticsUI = GuildLogisticsUI or {}
    GuildLogisticsUI.debugEnabled = (enabled ~= false)

    -- Affiche/masque l’onglet Debug si présent (même si l’accès principal est par le bouton)
    if UI.SetTabVisible then
        UI.SetTabVisible(Tr("tab_debug"), GuildLogisticsUI.debugEnabled)
    end

    -- ➕ Affiche/masque les boutons d’en-tête
    if UI.DebugButton and UI.DebugButton.SetShown then
        UI.DebugButton:SetShown(GuildLogisticsUI.debugEnabled)
    end
    if UI.ReloadButton and UI.ReloadButton.SetShown then
        UI.ReloadButton:SetShown(GuildLogisticsUI.debugEnabled)
    end

    -- Rafraîchit l'UI courante pour refléter le changement
    if UI.RefreshAll then UI.RefreshAll() end
end

-- ➕ Pastille sur un onglet
function UI.SetTabBadge(label, count)
    local b = UI.GetTabButton(label)
    if not b or not UI.AttachBadge then return end
    UI.AttachBadge(b):SetCount(tonumber(count) or 0)
end

-- ➕ Règle métier pour l'onglet "Demandes"
function UI.UpdateRequestsBadge()
    local isGM = (ns.GLOG and ns.GLOG.IsMaster and ns.GLOG.IsMaster()) or false
    local cnt = 0
    if isGM and ns.GLOG and ns.GLOG.GetRequests then
        local t = ns.GLOG.GetRequests()
        cnt = (type(t)=="table") and #t or 0
    end
    UI.SetTabBadge(Tr("tab_requests"), cnt)
    UI.SetTabVisible(Tr("tab_requests"), isGM and cnt > 0)
end

-- ➕ Hook « RefreshActive » utilisé par Comm.lua
function UI.RefreshActive()
    local isGM = (ns.GLOG and ns.GLOG.IsMaster and ns.GLOG.IsMaster()) or false
    if UI.SetTabVisible then
        UI.SetTabVisible(Tr("tab_start_raid"), isGM)
    end
    UI.UpdateRequestsBadge()
    UI.RefreshAll()
end

ns.RefreshActive = UI.RefreshActive

function ns.ToggleUI()
    if Main:IsShown() then
        Main:Hide()
    else
        Main:Show()

        -- refresh guilde si nécessaire (cache vide ou > 60s)
        if GLOG and GLOG.RefreshGuildCache then
            local ts = GLOG.GetGuildCacheTimestamp and GLOG.GetGuildCacheTimestamp() or 0
            local now = (time and time() or 0)
            local stale = (now - ts) > 60
            if stale or (GLOG.IsGuildCacheReady and not GLOG.IsGuildCacheReady()) then
                GLOG.RefreshGuildCache(function()
                    if ns.RefreshAll then ns.RefreshAll() end
                end)
            end
        end

        ShowPanel(1)
        if Registered[1] and Registered[1].refresh then Registered[1].refresh() end
    end
end

Main:Hide()

-- Ouvrir à l'ouverture du jeu + appliquer le thème et l'état de debug sauvegardés
local _openAtLogin = CreateFrame("Frame")
_openAtLogin:RegisterEvent("PLAYER_LOGIN")
_openAtLogin:SetScript("OnEvent", function()
    local saved = GLOG.GetSavedWindow and GLOG.GetSavedWindow() or {}

    -- Applique le thème stocké (défaut: AUTO) et re-skin global
    if UI.SetTheme then UI.SetTheme(saved.theme or "AUTO") end

    -- ✏️ Applique l'état de debug (défaut : false → boutons masqués)
    local debugOn = (saved and saved.debugEnabled) == true
    if UI.SetDebugEnabled then UI.SetDebugEnabled(debugOn) end

    -- Ouverture auto uniquement si activée par l'utilisateur
    if not (saved and saved.autoOpen) then return end
    if not Main:IsShown() then
        Main:Show()
        ShowPanel(1)
        if Registered[1] and Registered[1].refresh then Registered[1].refresh() end
    end
end)

-- ➕ Met à jour le titre selon la guilde
function UI.RefreshTitle()
    if Main and Main.title and Main.title.SetText then
        Main.title:SetText(GLOG.BuildMainTitle and GLOG.BuildMainTitle() or Tr("app_title"))
    end
end